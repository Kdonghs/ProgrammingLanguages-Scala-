class Foo {
  def apply() = 0
}
