object hw4 {
  def list_add(l1: List[Int], l2: List[Int]): List[Int] = {
    // ?
    return l2.reverse.zipAll(l1.reverse,0,0).collect{ case (a,b) => a+b }
  }

  def insort(l: List[Int], m: Int): List[Int] = {
    // ?
    return l.toArray.appended(m).sorted.toList
  }

  def ltake(l: List[Int], i: Int): List[Int] = {
    // ?
    return l.takeRight(i)
  }

  def lall(f: Int => Boolean, l: List[Int]): Boolean = {
    // ?
    return l.forall(f)
  }

  def lmap(f: Int => Int, l: List[Int]): List[Int] = {
    // ?
    return l.map(f)
  }

  def lfilter(f:Int => Boolean, l: List[Int]): List[Int] = {
    // ?
    return l.filter(f)
  }

  def ltabulate(n: Int, f: Int => Int): List[Int] = {
    // ?

    return List.tabulate(n)(f).reverse
  }

  def lrev(l: List[Int]): List[Int] = {
    // ?
    return l.reverse
  }

  def lconcat(l: List[List[Int]]): List[Int] = {
    // ?

    return l.flatten
  }

  def lfoldr(f: (Int, Int) => Int, l: List[Int], e: Int): Int = {
    // ?
    return l.foldRight(e)(f)
  }

  def lzip(a: List[String], b: List[Int]): List[(String, Int)] = {
    // ?
    return a.reverse.zip(b.reverse).reverse
  }

  def split(l: List[Int]): (List[Int], List[Int]) = {
    // ?
    return l.partition(_ % 2 == 1)
  }

  def cartprod(l1: List[Int], l2: List[Int]): List[(Int, Int)] = {
    // ?
    return l1.flatMap(x=>l2.map(y=>(x,y)))
  }

  def main(args: Array[String]): Unit = {
    println(list_add(List(1, 2, 3), List(1, 2, 3, 4, 5)))

    println(insort(List(1, 2, 4, 5), 3))

    println(ltake(List(1, 2, 3, 4), 2))

    println( lall(x => x > 0, List(1, 2, 3, 4)))

    println(lmap(x => x + 1, List(1, 2, 3)))

    println(lfilter(x => x > 2, List(1, 2, 3)))

    println(ltabulate(4, (x:Int) => x * x))

    println( lrev(List(1, 2, 3)))

    println(lconcat(List(List(1, 2, 3), List(4, 5, 6))))

    println(lfoldr((x:Int, y:Int) => x - y, List(1, 2, 3), 0))

    println(lzip(List("A", "B", "C", "D"), List(1, 2, 3, 4, 5, 6)))

    println( split(List(1, 2, 3, 4, 5)))

    println(cartprod(List(1, 2), List(3, 4, 5)))
  }

}
