object Foo_test {
  def main(args: Array[String]): Unit = {
    val foo = new Foo
    println(foo())
  }
}
